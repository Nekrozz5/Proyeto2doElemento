﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Libreria.Core.Entities;

namespace Libreria.Core.Interfaces
{
    public interface IFacturaRepository : IBaseRepository<Factura>
    {
        Task<IEnumerable<Factura>> GetFacturasPorClienteAsync(int clienteId);
        Task<IEnumerable<Factura>> GetAllWithDetailsAsync();
        Task<Factura?> GetByIdWithDetailsAsync(int id);
    }
}
