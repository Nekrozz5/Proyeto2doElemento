﻿using Libreria.Core.Entities;
using Libreria.Core.Services;
using Microsoft.AspNetCore.Mvc;

namespace Libreria.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FacturaController : ControllerBase
    {
        private readonly FacturaService _facturaService;

        public FacturaController(FacturaService facturaService)
        {
            _facturaService = facturaService;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var facturas = _facturaService.GetAll();
            return Ok(facturas);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var factura = await _facturaService.GetByIdAsync(id);
            if (factura == null)
                return NotFound();

            return Ok(factura);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Factura factura)
        {
            await _facturaService.AddAsync(factura);
            return Ok("Factura creada correctamente.");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Factura factura)
        {
            if (id != factura.Id)
                return BadRequest("El ID de la factura no coincide.");

            _facturaService.Update(factura);
            return Ok("Factura actualizada correctamente.");
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _facturaService.DeleteAsync(id);
            return Ok("Factura eliminada correctamente.");
        }
    }
}
