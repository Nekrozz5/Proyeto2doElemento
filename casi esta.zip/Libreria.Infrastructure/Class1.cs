﻿namespace Libreria.Infrastructure
{
    public class Class1
    {/*
        {
  "clienteId": 1,
  "detalles": [
    { "libroId": 2, "cantidad": 2 },
    { "libroId": 3, "cantidad": 1 }
  ]
}
*/
    }
}
