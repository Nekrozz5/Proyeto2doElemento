﻿using Libreria.Core.Entities;
using Libreria.Core.Interfaces;
using Libreria.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Libreria.Infrastructure.Repositories
{
    public class FacturaRepository : BaseRepository<Factura>, IFacturaRepository
    {
        private readonly ApplicationDbContext _context;

        public FacturaRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }

        // 🔹 Obtener todas las facturas sin incluir relaciones
        public async Task<IEnumerable<Factura>> GetAllAsync()
        {
            return await _context.Facturas.ToListAsync();
        }

        // 🔹 Obtener una factura simple por Id (sin relaciones)
        public async Task<Factura?> GetByIdAsync(int id)
        {
            return await _context.Facturas.FindAsync(id);
        }

        // 🔹 Agregar una factura (sin guardar aún — el UnitOfWork se encarga)
        public async Task AddAsync(Factura factura)
        {
            await _context.Facturas.AddAsync(factura);
        }

        // 🔹 Actualizar factura existente
        public async Task UpdateAsync(Factura factura)
        {
            _context.Facturas.Update(factura);
            await _context.SaveChangesAsync();
        }

        // 🔹 Eliminar factura existente
        public async Task DeleteAsync(Factura factura)
        {
            _context.Facturas.Remove(factura);
            await _context.SaveChangesAsync();
        }

        // 🔹 Obtener facturas por cliente
        public async Task<IEnumerable<Factura>> GetFacturasPorClienteAsync(int clienteId)
        {
            return await _context.Facturas
                .Where(f => f.ClienteId == clienteId)
                .Include(f => f.DetalleFacturas)
                .ToListAsync();
        }

        // ✅ NUEVOS MÉTODOS → para traer las relaciones completas
        public async Task<IEnumerable<Factura>> GetAllWithDetailsAsync()
        {
            var facturas = await _context.Facturas
                .Include(f => f.Cliente)
                .Include(f => f.DetalleFacturas)
                    .ThenInclude(df => df.Libro)
                .ToListAsync();

            // Calcular total de cada factura
            foreach (var f in facturas)
            {
                if (f.DetalleFacturas != null && f.DetalleFacturas.Any())
                    f.Total = f.DetalleFacturas.Sum(d => d.Cantidad * d.PrecioUnitario);
            }

            return facturas;
        }

        // ✅ Obtener una factura específica con cliente, detalles y libros
        public async Task<Factura?> GetByIdWithDetailsAsync(int id)
        {
            var factura = await _context.Facturas
                .Include(f => f.Cliente)
                .Include(f => f.DetalleFacturas)
                    .ThenInclude(df => df.Libro)
                .FirstOrDefaultAsync(f => f.Id == id);

            if (factura != null && factura.DetalleFacturas.Any())
                factura.Total = factura.DetalleFacturas.Sum(d => d.Cantidad * d.PrecioUnitario);

            return factura;
        }
    }
}
