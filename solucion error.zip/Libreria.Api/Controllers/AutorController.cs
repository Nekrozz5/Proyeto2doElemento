﻿using Libreria.Core.Entities;
using Libreria.Core.Services;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Libreria.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AutorController : ControllerBase
    {
        private readonly AutorService _autorService;

        public AutorController(AutorService autorService)
        {
            _autorService = autorService;
        }

        [HttpGet]
        public IActionResult Get() => Ok(_autorService.GetAll());

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            var autor = await _autorService.GetByIdAsync(id);
            if (autor == null) return NotFound();
            return Ok(autor);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Autor autor)
        {
            try
            {
                await _autorService.AddAsync(autor);
                return Ok(autor);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpPut("{id:int}")]
        public IActionResult Update(int id, [FromBody] Autor autor)
        {
            try
            {
                autor.Id = id;
                _autorService.Update(autor);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _autorService.DeleteAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }
    }
}
