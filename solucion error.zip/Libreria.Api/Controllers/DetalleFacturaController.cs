﻿using Libreria.Core.Entities;
using Libreria.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Libreria.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DetalleFacturaController : ControllerBase
    {
        private readonly IDetalleFacturaService _detalleFacturaService;

        public DetalleFacturaController(IDetalleFacturaService detalleFacturaService)
        {
            _detalleFacturaService = detalleFacturaService;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var detalles = _detalleFacturaService.GetAll();
            return Ok(detalles);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var detalle = await _detalleFacturaService.GetByIdAsync(id);
            if (detalle == null)
                return NotFound();

            return Ok(detalle);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] DetalleFactura detalle)
        {
            await _detalleFacturaService.AddAsync(detalle);
            return Ok(detalle);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] DetalleFactura detalle)
        {
            if (id != detalle.Id)
                return BadRequest("El ID no coincide.");

            await _detalleFacturaService.UpdateAsync(detalle);
            return Ok(detalle);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _detalleFacturaService.DeleteAsync(id);
            return Ok();
        }
    }
}
