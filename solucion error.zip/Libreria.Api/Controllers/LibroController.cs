﻿using Libreria.Core.Entities;
using Libreria.Core.Services;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Libreria.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LibroController : ControllerBase
    {
        private readonly LibroService _libroService;

        public LibroController(LibroService libroService)
        {
            _libroService = libroService;
        }

        [HttpGet]
        public IActionResult Get() => Ok(_libroService.GetAll());

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            var libro = await _libroService.GetByIdAsync(id);
            if (libro == null) return NotFound();
            return Ok(libro);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Libro libro)
        {
            try
            {
                await _libroService.AddAsync(libro);
                return Ok(libro);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpPut("{id:int}")]
        public IActionResult Update(int id, [FromBody] Libro libro)
        {
            try
            {
                libro.Id = id;
                _libroService.Update(libro);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _libroService.DeleteAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }
    }
}
