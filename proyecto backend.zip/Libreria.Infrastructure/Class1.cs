﻿namespace Libreria.Infrastructure
{
    public class Class1
    {

    }
}
