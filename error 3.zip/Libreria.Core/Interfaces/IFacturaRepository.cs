﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Libreria.Core.Entities;

namespace Libreria.Core.Interfaces
{
    public interface IFacturaRepository : IBaseRepository<Factura>
    {
        // Obtener una factura simple por Id (sin relaciones)
        Task<Factura?> GetByIdAsync(int id);

        // Obtener todas las facturas sin incluir relaciones
        Task<IEnumerable<Factura>> GetAllAsync();

        // Obtener facturas por cliente
        Task<IEnumerable<Factura>> GetFacturasPorClienteAsync(int clienteId);

        // Obtener todas las facturas con sus relaciones (Cliente + Detalle)
        Task<IEnumerable<Factura>> GetAllWithDetailsAsync();

        // Obtener una factura por Id incluyendo sus relaciones
        Task<Factura?> GetByIdWithDetailsAsync(int id);
    }
}
