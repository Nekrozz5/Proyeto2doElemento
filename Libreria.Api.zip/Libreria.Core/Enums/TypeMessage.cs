﻿namespace Libreria.Core.Enums
{
    public enum TypeMessage
    {
        success,
        warning,
        information,
        error
    }
}
